		<!-- Widgets list -->
		<ul class="template-widget-list">

			<!-- Categories widget -->
			<li>
				<h6>
					<span>Categories</span>
					<span></span>
				</h6>
				<div>
					<div class="template-widget-category template-widget-category-style-1">
						<ul>
							<li>
								<a href="<?php Template::getPageURL('blog-page-category'); ?>" title="Dance (2)">Dance (2)</a>
							</li>
							<li>
								<a href="<?php Template::getPageURL('blog-page-category'); ?>" title="Education (2)">Education (2)</a>
							</li>
							<li>
								<a href="<?php Template::getPageURL('blog-page-category'); ?>" title="Events (2)">Events (2)</a>
							</li>
							<li>
								<a href="<?php Template::getPageURL('blog-page-category'); ?>" title="Fun (2)">Fun (2)</a>
							</li>
							<li>
								<a href="<?php Template::getPageURL('blog-page-category'); ?>" title="Games (2)">Games (2)</a>
							</li>
							<li>
								<a href="<?php Template::getPageURL('blog-page-category'); ?>" title="General (2)">General (2)</a>
							</li>
						</ul>
					</div>										
				</div>
			</li>

			<!-- Tags widget -->
			<li>
				<h6>
					<span>Tags</span>
					<span></span>
				</h6>
				<div>
					<div class="template-widget-tag">
						<ul>
							<li><a href="<?php Template::getPageURL('blog-page-search'); ?>">Tag #1</a></li>
							<li><a href="<?php Template::getPageURL('blog-page-search'); ?>">Tag #2</a></li>
							<li><a href="<?php Template::getPageURL('blog-page-search'); ?>">Tag #3</a></li>
							<li><a href="<?php Template::getPageURL('blog-page-search'); ?>">Tag #4</a></li>
						</ul>
					</div>
				</div>
			</li>

		</ul>