		<div class="template-content-section template-padding-top-reset template-padding-bottom-reset">
			
			<!-- Google map -->
			<div class="template-component-google-map" id="template-component-google-map-1"></div>
		
		</div>