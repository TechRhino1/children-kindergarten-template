		<div class="template-section-white">
			<div class="template-component-counter-box template-state-carousel-enable">
				<ul class="template-layout-25x25x25x25 template-clear-fix">
					<li class="template-layout-column-left">
						<span class="template-component-counter-box-counter">
							<span class="template-component-counter-box-counter-value">507</span>
						</span>
						<h5>Our Pupils</h5>
						<p>Pulvinar forte maestro node terminal est elipsis prism.</p>
						<span class="template-component-counter-box-timeline template-state-hidden">
							<span></span>
						</span>
					</li>
					<li class="template-layout-column-center-left">
						<span class="template-component-counter-box-counter">
							<span class="template-component-counter-box-counter-value">235</span>
						</span>
						<h5>Teaching Hours</h5>
						<p>Elipsis morbi nulla a metro interdum vitae elite.</p>
						<span class="template-component-counter-box-timeline template-state-hidden">
							<span></span>
						</span>
					</li>
					<li class="template-layout-column-center-right">
						<span class="template-component-counter-box-counter">
							<span class="template-component-counter-box-counter-value">100</span>
							<span class="template-component-counter-box-counter-character">%</span>
						</span>
						<h5>Satisfied Parents</h5>
						<p>Elementum pulvinar detos diaspis movum blandit.</p>
						<span class="template-component-counter-box-timeline template-state-hidden">
							<span></span>
						</span>
					</li>
					<li class="template-layout-column-right">
						<span class="template-component-counter-box-counter">
							<span class="template-component-counter-box-counter-character"></span>
							<span class="template-component-counter-box-counter-value">1050</span>
						</span>
						<h5>Meals Per Year</h5>
						<p>Pulvinar forte maestro node terminal est elipsis prism.</p>
						<span class="template-component-counter-box-timeline template-state-hidden">
							<span></span>
						</span>
					</li>
					<li class="template-layout-column-left">
						<span class="template-component-counter-box-counter">
							<span class="template-component-counter-box-counter-character"></span>
							<span class="template-component-counter-box-counter-value">15</span>
						</span>
						<h5>Morning Session</h5>
						<p>Elipsis morbi nulla a metro interdum vitae elite.</p>
						<span class="template-component-counter-box-timeline template-state-hidden">
							<span></span>
						</span>
					</li>
					<li class="template-layout-column-center-left">
						<span class="template-component-counter-box-counter">
							<span class="template-component-counter-box-counter-character"></span>
							<span class="template-component-counter-box-counter-value">25</span>
						</span>
						<h5>Full Daycare</h5>
						<p>Elementum pulvinar detos diaspis movum blandit.</p>
						<span class="template-component-counter-box-timeline template-state-hidden">
							<span></span>
						</span>
					</li>
				</ul>
				<div class="template-pagination template-pagination-style-1"></div>
			</div>
		</div>