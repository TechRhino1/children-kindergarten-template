		<!-- Testimonials -->
		<div class="template-section-white">
			<div class="template-component-testimonial template-component-testimonial-style-2">
				<ul class="template-layout-100">
					<li class="template-layout-column-left">
						<i></i>
						<p>Fable Kindergarten is a great place for my daughter to start her schooling experience. It’s welcoming and safe and my daughter loves being there.</p>
						<div></div>
						<span>Fredric Greene</span>
					</li>
					<li class="template-layout-column-left">
						<i></i>
						<p>I have a 1 year old and a 5 year old who have been attending for a year now. I can not tell you how much I adore and appreciate all of the wonderful staff.</p>
						<div></div>
						<span>Patricia Morgan</span>
					</li>
					<li class="template-layout-column-left">
						<i></i>
						<p>I have to say that I have 2 children ages 5 and 2 and have used various daycare’s in Kindergartens and this is by far the very best I have ever used.</p>
						<div></div>
						<span>Joann Simms</span>
					</li>
					<li class="template-layout-column-left">
						<i></i>
						<p>Fable Kindergarten is a great place for my daughter to start her schooling experience. It’s welcoming and safe and my daughter loves being there.</p>
						<div></div>
						<span>Shelia Perry</span>
					</li>
					<li class="template-layout-column-left">
						<i></i>
						<p>This letter is to recognize you and your staff for doing an excellent job teaching my son. His skill level is significantly better since attending Fable.</p>
						<div></div>
						<span>Tony I. Robinette</span>
					</li>
					<li class="template-layout-column-left">
						<i></i>
						<p>I have to say that I have 2 children ages 5 and 2 and have used various daycare’s in Kindergartens and this is by far the very best I have ever used.</p>
						<div></div>
						<span>Claire Willmore</span>
					</li>
				</ul>
				<div class="template-pagination template-pagination-style-1"></div>
			</div>
		</div>