		<!-- Call to action -->
		<div class="template-component-call-to-action template-component-call-to-action-style-2">
			
			<!-- Content -->
			<div class="template-component-call-to-action-content">
				
				<!-- Left column -->
				<div class="template-component-call-to-action-content-left">
					
					<!-- Header -->
					<h3>How to Enroll Your Child to a Class?</h3>
				
				</div>
				
				<!-- Right column -->
				<div class="template-component-call-to-action-content-right">
					
					<!-- Button -->
					<a href="#" class="template-component-button template-component-button-style-1">Learn More<i></i></a>
				
				</div>									
			
			</div>
		
		</div>