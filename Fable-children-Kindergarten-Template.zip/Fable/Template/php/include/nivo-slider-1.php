<!-- Nivo slider -->
<div class="template-component-nivo-slider template-component-nivo-slider-style-1 template-preloader">
	<div>
		<img src="media/image/_sample/690x506/10.jpg" data-thumb="media/image/_sample/690x506/10.jpg" alt=""/>
		<img src="media/image/_sample/690x506/5.jpg" data-thumb="media/image/_sample/690x506/5.jpg" alt=""/>
		<img src="media/image/_sample/690x506/11.jpg" data-thumb="media/image/_sample/690x506/11.jpg" alt=""/>
	</div>
</div>