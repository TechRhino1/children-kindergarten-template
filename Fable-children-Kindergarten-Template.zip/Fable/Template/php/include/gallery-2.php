		<!-- Gallery -->
		<div class="template-component-gallery">
			
			<!-- Layout 25x25x25x25 -->
			<ul class="template-layout-25x25x25x25 template-layout-margin-reset template-clear-fix">
				
				<!-- Left column -->
				<li class="template-layout-column-left">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/5.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/5.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>
				</li>
				
				<!-- Center left column -->
				<li class="template-layout-column-center-left">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/6.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/6.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>			
				</li>
				
				<!-- Center right column -->
				<li class="template-layout-column-center-right">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/7.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/7.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>			
				</li>
				
				<!-- Right column -->
				<li class="template-layout-column-right">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/1.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/1.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>			
				</li>
				
				<!-- Left column -->
				<li class="template-layout-column-left">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/8.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/8.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>
				</li>
				
				<!-- Center left column -->
				<li class="template-layout-column-center-left">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/11.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/11.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>			
				</li>
				
				<!-- Center right column -->
				<li class="template-layout-column-center-right">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/12.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/12.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>			
				</li>
				
				<!-- Right column -->
				<li class="template-layout-column-right">
					<div class="template-component-image template-fancybox template-preloader">
						<a href="media/image/_sample/1050x770/4.jpg" data-fancybox-group="gallery-2">
							<img src="media/image/_sample/1050x770/4.jpg" alt="" />
							<span><span><span></span></span></span>
						</a>
					</div>			
				</li>
				
			</ul>
			
		</div>