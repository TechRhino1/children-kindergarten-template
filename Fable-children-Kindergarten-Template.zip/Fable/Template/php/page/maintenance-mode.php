		<!-- Content -->
		<div class="template-content">

			<!-- Section -->
			<div class="template-content-section template-background-image template-background-image-6">

				<!-- Main -->
				<div class="template-main template-section-white template-align-center">

					<!-- Feature -->
					<div class="template-component-feature template-component-feature-style-2 template-component-feature-position-top template-component-feature-size-large">
						<ul class="template-layout-100 template-clear-fix">
							<li class="template-layout-column-left">
								<div class="template-icon-feature template-icon-feature-name-lab-alt"></div>
							</li>
						</ul>
					</div>

					<!-- Header -->
					<h1>Closed For Maintenance</h1>

					<!-- Info -->
					<p>
						Our website is currently undergoing schedule maintenance.<br/>
						We are sorry for inconvenience and appreciate your patience.<br/>
						Please check later.
					</p>

				</div>

			</div>

		</div>