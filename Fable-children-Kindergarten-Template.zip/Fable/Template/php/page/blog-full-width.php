		<!-- Header -->
		<div class="template-header">

			<!-- Top header -->
			<div class="template-header-top">
				<?php Template::includeHeaderTop(); ?>
			</div>

			<!-- Bottom header -->
			<div class="template-header-bottom">
				<?php Template::includeHeaderBottom('Blog Full Width','Browse News From Our Kindergarten'); ?>
			</div>

		</div>

		<!-- Content -->
		<div class="template-content">

			<!-- Main -->
			<div class="template-content-section template-main template-clear-fix">
				<?php Template::includeFile('blog-2'); ?>
			</div>

		</div>